using UnityEngine;

public interface IWebRequestReponse 
{

}
